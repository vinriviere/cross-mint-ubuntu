
#include <sys/types.h>

uid_t __uid = 0;
gid_t __gid = 0;

