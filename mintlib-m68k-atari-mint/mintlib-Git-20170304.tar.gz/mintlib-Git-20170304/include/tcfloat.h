
#error "replace this file with float.h from the Pure/Turbo C distribution!"
