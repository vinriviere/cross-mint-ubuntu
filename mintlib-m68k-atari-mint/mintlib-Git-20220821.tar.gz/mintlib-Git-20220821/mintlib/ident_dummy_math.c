/* dummy ident string to satifsy extern reference in crt0.o if math library is
   not linked
 */
char __Ident_math[1];

