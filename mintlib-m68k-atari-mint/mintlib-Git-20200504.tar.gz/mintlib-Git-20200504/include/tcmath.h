#error "replace this file with math.h from the Pure/Turbo C distribution!"
