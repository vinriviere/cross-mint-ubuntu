/* This will avoid the construct L"". */

#include <stddef.h>

const wchar_t _wnull[1] = { 0 };
