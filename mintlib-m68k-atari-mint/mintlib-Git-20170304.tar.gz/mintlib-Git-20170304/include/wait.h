/* SVR4 ABI requires <wait.h> rather than <sys/wait.h> */
#include <sys/wait.h>
