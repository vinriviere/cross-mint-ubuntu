
#include <sys/types.h>

/* used in readdir, __do_stat, fstat */
ino_t __inode = 32;

